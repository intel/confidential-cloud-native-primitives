from py_gen.cli import CCNPClient
from cctrusted_vm import CCTrustedVmSdk
from report import Report

if __name__ == "__main__":
    resp = Report.get_report(Report.TYPE_TDX, "", "")
    print(resp)
    
    # cli = CCNPClient()
    # resp = cli.GetReport("","")
    # print(resp.report)
    # alg = CCTrustedVmSdk.inst().get_default_algorithms()
    # resp = cli.GetMeasurement(0, alg.alg_id)
    # print(resp.measurement)
    # resp = cli.GetEventlog(1, 3)
    # print(resp.events)