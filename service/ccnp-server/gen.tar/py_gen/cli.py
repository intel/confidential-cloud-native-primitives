import os
import ccnp_server_pb2_grpc
import ccnp_server_pb2

import grpc

DEFAULT_SOCK: str = "/run/ccnp/uds/ccnp-server.sock"

class CCNPClient:
    def __init__(self, sock: str = DEFAULT_SOCK):
        self._sock = sock
        
    def GetReport(self, level: ccnp_server_pb2.LEVEL, user_data: str, nonce: str) -> ccnp_server_pb2.GetReportResponse:
        stub = self._get_stub()
        req = ccnp_server_pb2.GetReportRequest(level, user_data, nonce)
        return stub.GetReport(req)
        
    def GetMeasurement():
        pass
    def GetEventlog():
        pass

    def _get_stub(self) -> ccnp_server_pb2_grpc.ccnpStub:
        if not os.path.exists(self._sock.replace('unix:', '')):
            raise RuntimeError("Quote server does not start.")
        channel = grpc.insecure_channel(self._sock,
                                        options=[('grpc.default_authority', 'localhost')])
        stub = ccnp_server_pb2_grpc.ccnpStub(channel)
        return stub

if __name__ == "__main__":
    cli = CCNPClient()
    resp = cli.GetReport(ccnp_server_pb2.LEVEL.PAAS, "", "")
    print(resp.report)
